from odoo import api, exceptions, fields, models

class Product_newfields(models.Model):
    _name='order.prepago'
    name=fields.Many2one('product.product', string="Equipo", domain="[('type','=','product')]")
    x_Stock=fields.Integer(string="Disponibles", readonly=True, compute="_get_stock")
    x_Serie = fields.Char(string="Serie")
    x_Contrato = fields.Char(string="No. Contrato")
    x_Unit = fields.Float(string="Unidades", default="1")
    x_Price = fields.Float(string="Precio", readonly=True, compute="_get_value")
    x_Subtotal = fields.Float(string="Subtotal", readonly=True, compute="_get_value2")

    @api.one
    @api.depends('name','x_Unit')
    def _get_value(self):
    	for record in self:
    		record['x_Price'] = self.name.list_price

    @api.one
    @api.depends('x_Price','x_Unit')
    def _get_value2(self):
    	for record in self:    		
            record['x_Subtotal'] = self.x_Unit*self.x_Price

    @api.one
    @api.depends('name')
    def _get_stock(self):
        for record in self:
            record['x_Stock'] = self.name.qty_available

    @api.one
    @api.constrains('x_Unit','x_Stock')
    def _check_unit_smaller_stock(self):
        if self.x_Stock < self.x_Unit:
            raise exceptions.ValidationError("No se dispone con todos los Equipos")