from odoo import api, fields, models

class Product_newfields(models.Model):
    _name='order.plan'

    name=fields.Many2one('product.product', string="Plan", domain="[('type','=','service')]")
    x_Unit = fields.Float(string="Unidades", default="1")
    x_Price = fields.Float(string="Precio Renta Mensual", readonly=True, compute="_get_value")
    x_Subtotal = fields.Float(string="Subtotal", readonly=True, compute="_get_value2")

    @api.one
    @api.depends('name','x_Unit')
    def _get_value(self):
    	for record in self:
    		record['x_Price'] = self.name.list_price

    @api.one
    @api.depends('x_Price','x_Unit')
    def _get_value2(self):
    	for record in self:    		
            record['x_Subtotal'] = self.x_Unit*self.x_Price