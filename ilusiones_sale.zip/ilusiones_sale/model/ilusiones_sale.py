from odoo import api, fields, models

class Ilusiones_sale(models.Model):
    _name='ilusiones.sale'	
	
    name = fields.Many2one('res.partner', string="Cliente", required=True)
    x_Fecha = fields.Datetime(string="Fecha", default=fields.Datetime.now)	
    x_CheckPrepago = fields.Boolean(string="Prepago")
    x_CheckPLan = fields.Boolean(string="Plan")
    x_CheckActivacion = fields.Boolean(string="Activacion")
    state = fields.Selection([('draft', "Borrador"), ('confirmed', "Abierto"), ('paid', "Pagado"),], default='draft', readonly=True)

    #Prepago
    x_OrderPrepago = fields.Many2many('order.prepago', string="Seleccione")
    #Plan
    x_OrderPlan = fields.Many2many('order.plan', string="Seleccione")
    #Activacion
    x_OrderActivacion = fields.Many2many('order.activacion', string="Seleccione")

    x_Total = fields.Float(string="Total", compute="_get_total")

    @api.multi
    def action_draft(self):
        self.state = 'draft'
	
    @api.multi
    def action_confirmed(self):        
        #for line in self.x_OrderPrepago:
         #   self._cr.execute("UPDATE stock_change_product_qty SET new_quantity="line.name.qty_available - line.x_Unit" WHERE id="line.name.id";")
        self.state = 'confirmed'
	
    @api.multi
    def action_paid(self):
        self.state = 'paid'

    @api.one
    @api.depends('x_OrderPrepago','x_OrderPlan', 'x_OrderActivacion')
    def _get_total(self):
        for line in self.x_OrderPrepago:
            self.x_Total = line.x_Subtotal + self.x_Total
        for line in self.x_OrderPlan:
            self.x_Total = line.x_Subtotal + self.x_Total
        for line in self.x_OrderActivacion:
            self.x_Total = line.x_Subtotal + self.x_Total