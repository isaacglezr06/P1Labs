# -*- coding: utf-8 -*-
{
    'name': "ilusiones_sale",

    'summary': """Modulo de Venta de Celulares""",

    'description': """
        En este modulo podremos hacer ventas de diferentes tipos:
            - Venta de Prepago
            - Venta de Plan
            - Venta de Activacion
    """,

    'author': "P1Labs",
    'website': "https://www.marcap.mx",
    'category': 'Test',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'stock', 'sale_management', 'contacts'],

    # always loaded
    'data': [        
        'view/activacion_view.xml',
        'view/ilusiones_sale.xml',
        'view/ilusiones_sale_report.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo.xml',
    ],
}